#!/bin/bash

# set attachPID to Process ID of THIS thread
export attachPID=$$

# Indicate the path to the Automator workflow file
workflowPath=$(echo ~/Library/Workflows/attachment-workflow.workflow)

# Execute Automator workflow passing in string containing environment variables
automator -i "ECID=$ECID&attachPID=$attachPID&PATH=$PATH&UDID=$UDID&deviceName=$deviceName &deviceType=$deviceType&buildVersion=$buildVersion&firmwareVersion=$firmwareVersion&locationID=$locationID" "${workflowPath}"

# Check if Cache File exists
if [ ! -f ~/Library/Caches/com.apple.configurator.AttachedDevices/$ECID.plist ]; then
	echo "Cache file not found - Automator Workflow completed successfully"
else
	# Cache file found - Need to check if the PID matches
	echo "Cache File Found - Test PID"
	# Get the PID from the file
	filePID=$(defaults read ~/Library/Caches/com.apple.configurator.AttachedDevices/$ECID.plist attachPID)
	if test $attachPID -eq $filePID
	then
		# The file was created by this PID so the Workflow Failed - Clean up
		echo "PID Match - Workflow has failed - Clean up"
		rm ~/Library/Caches/com.apple.configurator.AttachedDevices/$ECID.plist
	else 
		# Re-Entry - Do Nothing
		echo "Re-Entry - Do Nothing"
	fi
fi