-- Create_Single_Page_iPad_Web_App.applescript
-- Create Single-Page iPad Web App

-- Copyright (c) MACOSXAUTOMATION.COM. 2010. All rights reserved.

script Create_Single_Page_iPad_Web_App
	property parent : class "AMBundleAction"
	property NSString : class "NSString"
	
	property web_typeface_list : {"Arial, Helvetica, sans-serif", "'Arial Black', Gadget, sans-serif", "'Bookman Old Style', serif", "'Comic Sans MS', cursive", "'Courier New', Courier, monospace", "Garamond, serif", "Georgia, serif", "Impact, Charcoal, sans-serif", "'Lucida Console', Monaco, monospace", "'Lucida Sans Unicode', 'Lucida Grande', sans-serif", "'MS Sans Serif', Geneva, sans-serif", "'MS Serif', 'New York', sans-serif", "'Palatino Linotype', 'Book Antiqua', Palatino, serif", "Symbol, sans-serif", "Tahoma, Geneva, sans-serif", "'Times New Roman', Times, serif", "'Trebuchet MS', Helvetica, sans-serif", "Verdana, Geneva, sans-serif"}
	property iPad_typeface_list : {"'AcademyEngravedLetPlain', sans-serif", "'AmericanTypewriter', monospace", "'AppleGothic', sans-serif", "'ArialMT', sans-serif", "'Arial-BoldMT', sans-serif", "'Baskerville', serif", "'BodoniSvtyTwoITCTT', serif", "'BookmanOldStyle', serif", "'BradleyHandITCTT-Bold', cursive", "'Chalkduster', cursive", "'Cochin',serif", "'Copperplate',sans-serif", "'CourierNewPSMT', monospace", "'Didot', serif", "'Futura', sans-serif", "'Georgia', serif", "'GeezaPro', sans-serif", "'GillSans', sans-serif", "'Helvetica', sans-serif", "'HelveticaNeue', sans-serif", "'Hoefler Text', serif", "'MarkerFelt-Thin', sans-serif", "'MarkerFelt-Wide', sans-serif", "'Optima', sans-serif", "'Palatino', serif", "'Papyrus', sans-serif", "'Party LET', cursive", "'Snell Roundhand', cursive", "'Thonburi', sans-serif", "'Times New Roman', serif", "'Trebuchet MS', sans-serif", "'Verdana', sans-serif", "'Zapfino', cursive"}
	property large_size_list : {"36", "48", "64", "72", "96", "128"}
	property small_size_list : {"10", "12", "14", "16", "18", "20", "22", "24"}
	property small_letterspace_list : {"-1", "normal", "1", "2"}
	property large_letterspace_list : {"-4", "-2", "normal", "2", "4", "8", "16"}
	property color_list : {"aqua", "black", "blue", "fuchsia", "gray", "green", "lime", "maroon", "navy", "olive", "purple", "red", "silver", "teal", "white", "yellow", "#FFFFCC", "#CCCCCC", "#E1DAC1", "#DAE1DF", "#F8F0F8", "#F0F8FF", "#F0F4F0", "#FFFFF8", "#FFF4F0", "#E2DFD0", "#EDEDCF", "#FFF0F8", "#E4E5B8"}
	
	on runWithInput_fromAction_error_(input, anAction, errorRef)
		try
			log ("AUTOMATOR ACTION Create Single-Page iPad Web App")
			
			-- GET PARAMETERS RECORD
			set parameters to my parameters()
			
			-- EXTRACT THE VARIOUS VALUES FOR THE INPUT PARAMETERS
			set appName to parameters's valueForKey_("appName") as string
			
			set projectTitle to parameters's valueForKey_("projectTitle") as string
			set projectSubHead to parameters's valueForKey_("projectSubHead") as string
			set projectAuthor to parameters's valueForKey_("projectAuthor") as string
			set projectCopyRight to parameters's valueForKey_("projectCopyRight") as string
			
			log ("AUTOMATOR ACTION appName: " & appName)
			log ("AUTOMATOR ACTION projectTitle: " & projectTitle)
			log ("AUTOMATOR ACTION projectSubHead: " & projectSubHead)
			log ("AUTOMATOR ACTION projectAuthor: " & projectAuthor)
			log ("AUTOMATOR ACTION projectCopyRight: " & projectCopyRight)
			
			set mediaPath to parameters's valueForKey_("mediaPath") as string
			set mediaInsertionLocation to parameters's valueForKey_("mediaInsertionLocation") as integer
			set mediaCaption to parameters's valueForKey_("mediaCaption") as string
			set useEmbeddedMetadata to parameters's valueForKey_("useEmbeddedMetadata") as boolean
			
			log ("AUTOMATOR ACTION mediaPath: " & mediaPath)
			log ("AUTOMATOR ACTION mediaInsertionLocation: " & mediaInsertionLocation)
			log ("AUTOMATOR ACTION mediaCaption: " & mediaCaption)
			log ("AUTOMATOR ACTION useEmbeddedMetadata: " & useEmbeddedMetadata)
			
			set secondMediaPath to parameters's valueForKey_("secondMediaPath") as string
			set secondMediaInsertionLocation to parameters's valueForKey_("secondMediaInsertionLocation") as integer
			set secondMediaCaption to parameters's valueForKey_("secondMediaCaption") as string
			set useSecondEmbeddedMetadata to parameters's valueForKey_("useSecondEmbeddedMetadata") as boolean
			
			log ("AUTOMATOR ACTION secondMediaPath: " & secondMediaPath)
			log ("AUTOMATOR ACTION secondMediaInsertionLocation: " & secondMediaInsertionLocation)
			log ("AUTOMATOR ACTION secondMediaCaption: " & secondMediaCaption)
			log ("AUTOMATOR ACTION useSecondEmbeddedMetadata: " & useSecondEmbeddedMetadata)
			
			set metadataDescription to parameters's valueForKey_("metadataDescription") as string
			set metadataKeywords to parameters's valueForKey_("metadataKeywords") as string
			
			log ("AUTOMATOR ACTION metadataDescription: " & metadataDescription)
			log ("AUTOMATOR ACTION metadataKeywords: " & metadataKeywords)
			
			set typeTitleFontFamily to parameters's valueForKey_("typeTitleFontFamily") as integer
			set typeTitleFontFamily to item (typeTitleFontFamily + 1) of iPad_typeface_list
			set typeTitleSize to parameters's valueForKey_("typeTitleSize") as integer
			set typeTitleSize to item (typeTitleSize + 1) of large_size_list
			set typeTitleColor to parameters's valueForKey_("typeTitleColor") as integer
			set typeTitleColor to item (typeTitleColor + 1) of color_list
			set typeTitleLetterspace to parameters's valueForKey_("typeTitleLetterSpace") as integer
			set typeTitleLetterspace to item (typeTitleLetterspace + 1) of large_letterspace_list
			if typeTitleLetterspace is not "normal" then set typeTitleLetterspace to typeTitleLetterspace & "px"
			
			log ("AUTOMATOR ACTION typeTitleFontFamily: " & typeTitleFontFamily)
			log ("AUTOMATOR ACTION typeTitleSize: " & typeTitleSize)
			log ("AUTOMATOR ACTION typeTitleColor: " & typeTitleColor)
			log ("AUTOMATOR ACTION typeTitleLetterspace: " & typeTitleLetterspace)
			
			set typeSubHeadFontFamily to parameters's valueForKey_("typeSubHeadFontFamily") as integer
			set typeSubHeadFontFamily to item (typeSubHeadFontFamily + 1) of iPad_typeface_list
			set typeSubHeadSize to parameters's valueForKey_("typeSubHeadSize") as integer
			set typeSubHeadSize to item (typeSubHeadSize + 1) of small_size_list
			set typeSubHeadColor to parameters's valueForKey_("typeSubHeadColor") as integer
			set typeSubHeadColor to item (typeSubHeadColor + 1) of color_list
			set typeSubHeadLetterSpace to parameters's valueForKey_("typeSubHeadLetterSpace") as integer
			set typeSubHeadLetterSpace to item (typeSubHeadLetterSpace + 1) of small_letterspace_list
			if typeSubHeadLetterSpace is not "normal" then set typeSubHeadLetterSpace to typeSubHeadLetterSpace & "px"
			
			log ("AUTOMATOR ACTION typeSubHeadFontFamily: " & typeSubHeadFontFamily)
			log ("AUTOMATOR ACTION typeSubHeadSize: " & typeSubHeadSize)
			log ("AUTOMATOR ACTION typeSubHeadColor: " & typeSubHeadColor)
			log ("AUTOMATOR ACTION typeSubHeadLetterSpace: " & typeSubHeadLetterSpace)
			
			set typeAuthorFontFamily to parameters's valueForKey_("typeAuthorFontFamily") as integer
			set typeAuthorFontFamily to item (typeAuthorFontFamily + 1) of iPad_typeface_list
			set typeAuthorSize to parameters's valueForKey_("typeAuthorSize") as integer
			set typeAuthorSize to item (typeAuthorSize + 1) of small_size_list
			set typeAuthorColor to parameters's valueForKey_("typeAuthorColor") as integer
			set typeAuthorColor to item (typeAuthorColor + 1) of color_list
			set typeAuthorLetterSpace to parameters's valueForKey_("typeAuthorLetterSpace") as integer
			set typeAuthorLetterSpace to item (typeAuthorLetterSpace + 1) of small_letterspace_list
			if typeAuthorLetterSpace is not "normal" then set typeAuthorLetterSpace to typeAuthorLetterSpace & "px"
			
			log ("AUTOMATOR ACTION typeAuthorFontFamily: " & typeAuthorFontFamily)
			log ("AUTOMATOR ACTION typeAuthorSize: " & typeAuthorSize)
			log ("AUTOMATOR ACTION typeAuthorColor: " & typeAuthorColor)
			log ("AUTOMATOR ACTION typeAuthorLetterSpace: " & typeAuthorLetterSpace)
			
			set typeCopyrightFontFamily to parameters's valueForKey_("typeCopyrightFontFamily") as integer
			set typeCopyrightFontFamily to item (typeCopyrightFontFamily + 1) of iPad_typeface_list
			set typeCopyrightSize to parameters's valueForKey_("typeCopyrightSize") as integer
			set typeCopyrightSize to item (typeCopyrightSize + 1) of small_size_list
			set typeCopyrightColor to parameters's valueForKey_("typeCopyrightColor") as integer
			set typeCopyrightColor to item (typeCopyrightColor + 1) of color_list
			set typeCopyrightLetterSpace to parameters's valueForKey_("typeCopyrightLetterSpace") as integer
			set typeCopyrightLetterSpace to item (typeCopyrightLetterSpace + 1) of small_letterspace_list
			if typeCopyrightLetterSpace is not "normal" then set typeCopyrightLetterSpace to typeCopyrightLetterSpace & "px"
			
			log ("AUTOMATOR ACTION typeCopyrightFontFamily: " & typeCopyrightFontFamily)
			log ("AUTOMATOR ACTION typeCopyrightSize: " & typeCopyrightSize)
			log ("AUTOMATOR ACTION typeCopyrightColor: " & typeCopyrightColor)
			log ("AUTOMATOR ACTION typeCopyrightLetterSpace: " & typeCopyrightLetterSpace)
			
			set typeStoryFontFamily to parameters's valueForKey_("typeStoryFontFamily") as integer
			set typeStoryFontFamily to item (typeStoryFontFamily + 1) of iPad_typeface_list
			set typeStorySize to parameters's valueForKey_("typeStorySize") as integer
			set typeStorySize to item (typeStorySize + 1) of small_size_list
			set typeStoryColor to parameters's valueForKey_("typeStoryColor") as integer
			set typeStoryColor to item (typeStoryColor + 1) of color_list
			set typeStoryLetterspace to parameters's valueForKey_("typeStoryLetterSpace") as integer
			set typeStoryLetterspace to item (typeStoryLetterspace + 1) of small_letterspace_list
			if typeStoryLetterspace is not "normal" then set typeStoryLetterspace to typeStoryLetterspace & "px"
			
			log ("AUTOMATOR ACTION typeStoryFontFamily: " & typeStoryFontFamily)
			log ("AUTOMATOR ACTION typeStorySize: " & typeStorySize)
			log ("AUTOMATOR ACTION typeStoryColor: " & typeStoryColor)
			log ("AUTOMATOR ACTION typeStoryLetterspace: " & typeStoryLetterspace)
			
			set typePageColor to parameters's valueForKey_("typePageColor") as integer
			set typePageColor to item (typePageColor + 1) of color_list
			
			log ("AUTOMATOR ACTION typePageColor: " & typePageColor)
			
			set ccLicenseIndicator to parameters's valueForKey_("ccLicenseIndicator") as integer
			
			log ("AUTOMATOR ACTION ccLicenseIndicator: " & ccLicenseIndicator)
			
			
			set new_line to character id 10
			
			-- GENERATE A UUID FOR THE DESINTATION FOLDER
			set target_UUID to (do shell script "uuidgen")
			-- CREATE THE FOLDER
			tell application "Finder"
				-- make a new folder on the desktop to contain the project
				set the target_folder_HFSpath to (make new folder at desktop with properties {name:target_UUID}) as string
			end tell
			
			-- MEDIA HANDLERS
			if mediaPath is not "" then
				set mediaPath to do shell script "echo " & quoted form of mediaPath
				set the type_tree_list to my extract_content_tree(mediaPath)
				set the item_type to the first item of the type_tree_list
				
				if the type_tree_list contains "public.image" then
					log ("AUTOMATOR ACTION 1st media is image")
					set the media_HTML to my process_image(mediaPath, target_folder_HFSpath, "image1.jpg")
					if useEmbeddedMetadata is true then
						set the media_caption to my extract_caption(mediaPath)
						if the media_caption is false then
							set media_caption to ""
						else
							if media_caption is not "" then
								set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & media_caption & "</p>")
							end if
						end if
					else if mediaCaption is not "" then
						set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & mediaCaption & "</p>")
					end if
				else if the type_tree_list contains "public.movie" then
					log ("AUTOMATOR ACTION 1st media is movie")
					set the movieFile to mediaPath as POSIX file as alias
					tell application "Finder"
						set the movie_filename to the name of movieFile
						with timeout of 600 seconds
							set this_file to duplicate movieFile to folder target_folder_HFSpath
						end timeout
					end tell
					copy my extract_dimensions(mediaPath) to {movie_width, movie_height}
					if movie_width as integer is greater than 720 then
						set the movie_height to (720 * (movie_height as integer)) / (movie_width as integer)
						set movie_height to (round movie_height rounding as taught in school) as string
						set movie_width to "720"
					end if
					if mediaInsertionLocation is 0 then
						set the media_HTML to "<video src=\"" & movie_filename & "\" controls=\"controls\" height=\"" & movie_height & "\" width=\"" & movie_width & "\"></video>"
					else
						set the media_HTML to tab & tab & tab & "<video src=\"" & movie_filename & "\" controls=\"controls\" width=\"" & movie_width & "\"></video>"
					end if
					if useEmbeddedMetadata is true then
						set the media_caption to my extract_caption(mediaPath)
						if the media_caption is false then
							set media_caption to ""
						else
							if media_caption is not "" then
								set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & media_caption & "</p>")
							end if
						end if
					else if mediaCaption is not "" then
						set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & mediaCaption & "</p>")
					end if
				else if the type_tree_list contains "public.audio" then
					log ("AUTOMATOR ACTION 1st media is audio")
					-- CHECK AUDIO FILE
					set the audio_data to my return_audioinfo(mediaPath)
					if audio_data is false then
						error "Indicated audio file was not a valid audio file or was protected."
					else
						copy audio_data to {audio_file_type, audiosample_rate}
					end if
					if audio_file_type is in {"AIFF", "Sd2f", "WAVE"} then
						set encode_audio_file to true
					else -- {"m4af"}
						set encode_audio_file to false
					end if
					
					-- PROCESS AUDIO FILE IF NEEDED
					if encode_audio_file is true then
						set the audio_filename to "audio.m4a"
						set target_audio_file to target_folder_HFSpath & audio_filename
						set the command_string to "afconvert -f 'm4af' -d 'aac ' -s 1 " & (quoted form of the mediaPath) & space & (quoted form of the POSIX path of the target_audio_file)
						tell application "System Events"
							do shell script command_string
						end tell
					else
						set the media_file to mediaPath as POSIX file as alias
						tell application "Finder"
							set the audio_filename to the name of media_file
							set this_file to duplicate media_file to folder target_folder_HFSpath
						end tell
					end if
					
					set the media_HTML to "<audio src=\"" & (my replace_chars(audio_filename, " ", "%20")) & "\" controls=\"controls\" style=\"max-width:75%;\"></audio>"
					
					if useEmbeddedMetadata is true then
						set the media_caption to my extract_caption(mediaPath)
						if the media_caption is false then
							set media_caption to ""
						else
							if media_caption is not "" then
								set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & media_caption & "</p>")
							end if
						end if
					else if mediaCaption is not "" then
						set the media_HTML to the media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & mediaCaption & "</p>")
					end if
					
				end if
			else
				log ("AUTOMATOR ACTION no 1st media")
				set mediaPath to ""
			end if
			
			if secondMediaPath is not "" then
				set secondMediaPath to do shell script "echo " & quoted form of secondMediaPath
				set the type_tree_list to my extract_content_tree(secondMediaPath)
				set the item_type to the first item of the type_tree_list
				
				if the type_tree_list contains "public.image" then
					log ("AUTOMATOR ACTION 2nd media is image")
					set the second_media_HTML to my process_image(secondMediaPath, target_folder_HFSpath, "image2.jpg")
					if useSecondEmbeddedMetadata is true then
						set the second_media_caption to my extract_caption(secondMediaPath)
						if the second_media_caption is false then
							set second_media_caption to ""
						else
							if second_media_caption is not "" then
								set the second_media_HTML to the second_media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & second_media_caption & "</p>")
							end if
						end if
					else if secondMediaCaption is not "" then
						set the second_media_HTML to the second_media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & secondMediaCaption & "</p>")
					end if
				else if the type_tree_list contains "public.movie" then
					log ("AUTOMATOR ACTION 2nd media is movie")
					set the secondMovieFile to secondMediaPath as POSIX file as alias
					tell application "Finder"
						set the second_movie_filename to the name of secondMovieFile
						with timeout of 600 seconds
							set this_file to duplicate secondMovieFile to folder target_folder_HFSpath
						end timeout
					end tell
					copy my extract_dimensions(secondMediaPath) to {movie_width, movie_height}
					if movie_width as integer is greater than 720 then
						set the movie_height to (720 * (movie_height as integer)) / (movie_width as integer)
						set movie_height to (round movie_height rounding as taught in school) as string
						set movie_width to "720"
					end if
					if secondMediaInsertionLocation is 0 then
						set the second_media_HTML to "<video src=\"" & second_movie_filename & "\" controls=\"controls\" height=\"" & movie_height & "\" width=\"" & movie_width & "\"></video>"
					else
						set the second_media_HTML to tab & tab & tab & "<video src=\"" & second_movie_filename & "\" controls=\"controls\" width=\"" & movie_width & "\"></video>"
					end if
					if useSecondEmbeddedMetadata is true then
						set the second_media_caption to my extract_caption(secondMediaPath)
						if the second_media_caption is false then
							set second_media_caption to ""
						else
							if second_media_caption is not "" then
								set the second_media_HTML to the second_media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & second_media_caption & "</p>")
							end if
						end if
					else if secondMediaCaption is not "" then
						set the second_media_HTML to the second_media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & secondMediaCaption & "</p>")
					end if
				else if the type_tree_list contains "public.audio" then
					log ("AUTOMATOR ACTION 2nd media is audio")
					-- CHECK AUDIO FILE
					set the audio_data to my return_audioinfo(secondMediaPath)
					if audio_data is false then
						error "Indicated audio file was not a valid audio file or was protected."
					else
						copy audio_data to {audio_file_type, audiosample_rate}
					end if
					if audio_file_type is in {"AIFF", "Sd2f", "WAVE"} then
						set encode_audio_file to true
					else -- {"m4af"}
						set encode_audio_file to false
					end if
					
					-- PROCESS AUDIO FILE IF NEEDED
					if encode_audio_file is true then
						set the second_audio_filename to "audio2.m4a"
						set target_audio_file to target_folder_HFSpath & second_audio_filename
						set the command_string to "afconvert -f 'm4af' -d 'aac ' -s 1 " & (quoted form of the secondMediaPath) & space & (quoted form of the POSIX path of the target_audio_file)
						tell application "System Events"
							do shell script command_string
						end tell
					else
						set the second_media_file to secondMediaPath as POSIX file as alias
						tell application "Finder"
							set the second_audio_filename to the name of second_media_file
							set this_file to duplicate second_media_file to folder target_folder_HFSpath
						end tell
					end if
					
					set the second_media_HTML to "<audio src=\"" & (my replace_chars(second_audio_filename, " ", "%20")) & "\" controls=\"controls\" style=\"max-width:75%;\"></audio>"
					
					if useSecondEmbeddedMetadata is true then
						set the second_media_caption to my extract_caption(secondMediaPath)
						if the second_media_caption is false then
							set second_media_caption to ""
						else
							if second_media_caption is not "" then
								set the second_media_HTML to the second_media_HTML & new_line & tab & tab & tab & ("<p class=\"caption\">" & second_media_caption & "</p>")
							end if
						end if
					else if secondMediaCaption is not "" then
						set the second_media_caption to the second_media_caption & new_line & tab & tab & tab & ("<p class=\"caption\">" & secondMediaCaption & "</p>")
					end if
					
				end if
			else
				log ("AUTOMATOR ACTION no 2nd media")
				set secondMediaPath to ""
			end if
			
			-- BUILD THE HEADER HTML
			log ("AUTOMATOR ACTION building header HTML")
			if projectTitle is "" then set projectTitle to "Untitled"
			set projectTitleHTML to tab & tab & tab & "<p class=\"headline\">" & projectTitle & "</p>"
			set the header_HTML to projectTitleHTML
			
			if projectSubHead is not "" then
				set the header_HTML to the header_HTML & new_line & tab & tab & tab & ("<p class=\"sub-head\">" & projectSubHead & "</p>")
			end if
			
			if projectAuthor is not "" then
				set the header_HTML to the header_HTML & new_line & tab & tab & tab & ("<p class=\"author\">" & projectAuthor & "</p>")
			end if
			
			if projectCopyRight is not "" then
				set the header_HTML to the header_HTML & new_line & tab & tab & tab & ("<p class=\"copyright\">" & projectCopyRight & "</p>")
			end if
			
			-- BUILD THE STORY CONTENT
			log ("AUTOMATOR ACTION building story HTML")
			-- replace characters used to tag HTML with codes
			set thisText to my replace_chars((input as string), "&", "&amp;")
			set thisText to my replace_chars(thisText, "<", "&lt;")
			set thisText to my replace_chars(thisText, ">", "&gt;")
			set these_paragraphs to every paragraph of thisText
			repeat with i from 1 to the count of these_paragraphs
				set this_paragraph to item i of these_paragraphs
				if this_paragraph is "" then set this_paragraph to "&nbsp;"
				if i is 1 then
					set passed_body_text to tab & tab & tab & "<p class=\"bodyCopy\">" & this_paragraph & "</p>"
				else
					set passed_body_text to passed_body_text & new_line & tab & tab & tab & "<p class=\"bodyCopy\">" & this_paragraph & "</p>"
				end if
			end repeat
			-- CREATIVE COMMONS LICENSE
			if ccLicenseIndicator is not 0 then
				set passed_body_text to passed_body_text & linefeed & tab & tab & tab & "<p class=\"copyright\">" & item ccLicenseIndicator of {"<a rel=\"license\" href=\"http://creativecommons.org/licenses/by/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by/3.0/us/80x15.png\" align=\"left\"></a>&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by/3.0/us/\">Creative Commons Attribution 3.0 United States License</a>.", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-sa/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-sa/3.0/us/80x15.png\" align=\"left\"></a>&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-sa/3.0/us/\">Creative Commons Attribution-Share Alike 3.0 United States License</a>.", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nd/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nd/3.0/us/80x15.png\" align=\"left\">&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nd/3.0/us/\">Creative Commons Attribution-No Derivative Works 3.0 United States License</a>.", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc/3.0/us/80x15.png\" align=\"left\">&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc/3.0/us/\">Creative Commons Attribution-Noncommercial 3.0 United States License</a>.", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc-sa/3.0/us/80x15.png\" align=\"left\">&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/3.0/us/\">Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License</a>.", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-nd/3.0/us/\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc-nd/3.0/us/80x15.png\" align=\"left\">&nbsp;This work is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-nd/3.0/us/\">Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 United States License</a>."} & "</p>"
			end if
			
			-- ADD MEDIA IF APPROPRIATE TO DO SO
			log ("AUTOMATOR ACTION adding media into HTML (if needed)")
			if mediaPath is not "" and secondMediaPath is "" then -- 1st MEDIA FILE ONLY
				if mediaInsertionLocation is 0 then -- at the top
					set the main_content to media_HTML & new_line & header_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 1 then -- after the title and attributions
					set the main_content to header_HTML & new_line & media_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 2 then -- at the end
					set the main_content to header_HTML & new_line & passed_body_text & new_line & media_HTML
				end if
			else if mediaPath is "" and secondMediaPath is not "" then -- 2nd MEDIA FILE ONLY
				if secondMediaInsertionLocation is 0 then -- at the top
					set the main_content to second_media_HTML & new_line & header_HTML & new_line & passed_body_text
				else if secondMediaInsertionLocation is 1 then -- after the title and attributions
					set the main_content to header_HTML & new_line & second_media_HTML & new_line & passed_body_text
				else if secondMediaInsertionLocation is 2 then -- at the end
					set the main_content to header_HTML & new_line & passed_body_text & new_line & second_media_HTML
				end if
			else if mediaPath is not "" and secondMediaPath is not "" then -- 1st & 2nd MEDIA FILES
				if mediaInsertionLocation is 0 and secondMediaInsertionLocation is 0 then -- both at the top
					set the main_content to media_HTML & new_line & second_media_HTML & new_line & header_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 0 and secondMediaInsertionLocation is 1 then -- 1st at top, 2nd before story
					set the main_content to media_HTML & new_line & header_HTML & new_line & second_media_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 0 and secondMediaInsertionLocation is 2 then -- 1st at top, 2nd after story
					set the main_content to media_HTML & new_line & header_HTML & new_line & passed_body_text & new_line & second_media_HTML
					
				else if mediaInsertionLocation is 1 and secondMediaInsertionLocation is 0 then -- 1st before story, 2nd at the top
					set the main_content to second_media_HTML & new_line & header_HTML & new_line & media_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 1 and secondMediaInsertionLocation is 1 then -- 1st before story, 2nd before story
					set the main_content to header_HTML & new_line & media_HTML & new_line & second_media_HTML & new_line & passed_body_text
				else if mediaInsertionLocation is 1 and secondMediaInsertionLocation is 2 then -- 1st before story, 2nd after story
					set the main_content to header_HTML & new_line & media_HTML & new_line & passed_body_text & second_media_HTML
					
				else if mediaInsertionLocation is 2 and secondMediaInsertionLocation is 0 then -- 1st after story, 2nd at the top
					set the main_content to second_media_HTML & new_line & header_HTML & new_line & passed_body_text & new_line & media_HTML
				else if mediaInsertionLocation is 2 and secondMediaInsertionLocation is 1 then -- 1st after story, 2nd before story
					set the main_content to header_HTML & new_line & second_media_HTML & new_line & passed_body_text & new_line & media_HTML
				else if mediaInsertionLocation is 2 and secondMediaInsertionLocation is 2 then -- 1st after story, 2nd after story
					set the main_content to header_HTML & new_line & passed_body_text & new_line & media_HTML & new_line & second_media_HTML
				end if
			else
				set the main_content to header_HTML & new_line & passed_body_text
			end if
			-- add blank lines at the end
			repeat 3 times
				set main_content to main_content & new_line & tab & tab & tab & "<p>&nbsp;</p>"
			end repeat
			
			log ("AUTOMATOR ACTION constructing HTML")
			set the HTML_text to "<!DOCTYPE html>
<html manifest=\"webapp.manifest\">
	<head>
		<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">
		<!-- iPad Setup -->
		<meta name=\"viewport\" content=\"minimum-scale=1.0, maximum-scale=1.0, width=device-width, user-scalable=no\">
		<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
		<!-- Metadata -->
		<meta name=\"author\" content=\"" & projectAuthor & "\">
		<meta name=\"description\" content=\"" & metadataDescription & "\">
		<meta name=\"keywords\" content=\"" & metadataKeywords & "\">
		
		<title>" & projectTitle & "</title>
					
		<style type=\"text/css\">
			body { margin: 0px; }
		
			#mainContent
			{
				background-color: " & typePageColor & ";
				padding: 36px 24px 24px 24px;
			}
			#mainContent p /* STORY */
			{
				color: " & typeStoryColor & ";
				font-family: " & typeStoryFontFamily & ";
				font-size: " & typeStorySize & "px;
				font-style: normal;
				margin: 0 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeStoryLetterspace & ";
			}
			#mainContent p.headline
			{
				color: " & typeTitleColor & ";
				font-family: " & typeTitleFontFamily & ";
				font-size: " & typeTitleSize & "px;
				font-style: normal;
				margin: 0 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeTitleLetterspace & ";
			}
			#mainContent p.sub-head
			{
				color: " & typeSubHeadColor & ";
				font-family: " & typeSubHeadFontFamily & ";
				font-size: " & typeSubHeadSize & "px;
				font-style: normal;
				margin: 0 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeSubHeadLetterSpace & ";
			}
			#mainContent p.author
			{
				color: " & typeAuthorColor & ";
				font-family: " & typeAuthorFontFamily & ";
				font-size: " & typeAuthorSize & "px;
				font-style: normal;
				margin: 0 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeAuthorLetterSpace & ";
			}
			#mainContent p.copyright
			{
				color: " & typeCopyrightColor & ";
				font-family: " & typeCopyrightFontFamily & ";
				font-size: " & typeCopyrightSize & "px;
				font-style: italic;
                margin: 12px 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeCopyrightLetterSpace & ";
			}
			#mainContent p.caption
			{
				color: " & typeCopyrightColor & ";
				font-family: " & typeCopyrightFontFamily & ";
				font-size: " & typeCopyrightSize & "px;
				font-style: italic;
				margin: 6px 0 6px 0;
				text-align: left;
				line-height: 120%;
				letter-spacing: " & typeCopyrightLetterSpace & ";
			}
			#mainContent audio { margin-bottom: 12px;  margin-top: 12px; width: 100%}
			#mainContent video { margin-bottom: 6px; }
            img.plustext
            {
                display: block;
                position: absolute;
                float: right;
                top: 40px;
                right: 24px;
                width: 26px;
                height: 23px;
                z-index: 2;
            }
            img.minustext
            {
                display: block;
                position: absolute;
                float: right;
                top: 40px;
                right: 50px;
                width: 27px;
                height: 23px;
                z-index:2;
            }
		</style>
        <script type=\"text/javascript\">
            function resizeText(multiplier) {
                var elems = document.getElementsByClassName('bodyCopy');
                for (i=0;i<elems.length;i++){
                    var thisParagraph = elems[i];
                    var textSize = thisParagraph.style.fontSize;
                    if (textSize == \"\") {
                        thisParagraph.style.fontSize = (" & (typeStorySize as string) & " + \"px\");
                    }
                    thisParagraph.style.fontSize = parseFloat(thisParagraph.style.fontSize) + multiplier + \"px\";
                }
            }
        </script>
	</head>
	<body>
		<div id=\"mainContent\">
			<img id=\"plustext\" class=\"plustext\" alt=\"Increase text size\" src=\"makeTextBigger.png\" onclick=\"resizeText(1)\" />
			<img id=\"minustext\" class=\"minustext\" alt=\"Decrease text size\" src=\"makeTextSmaller.png\" onclick=\"resizeText(-1)\" />
			" & main_content & "
		</div>
	</body>
</html>"
			
			-- WRITE THE FILE TO THE DESTINATION FOLDER
			log ("AUTOMATOR ACTION writing index.html file to target folder")
			set the target_file to target_folder_HFSpath & "index.html"
			if my write_to_file(HTML_text, target_file, false) is false then
				error (my NSLocalizedString("INDEX_WRITE_ERROR"))
			end if
			
			-- COPY THE TEXT SIZING IMAGES TO THE TARGET FOLDER
			log ("AUTOMATOR ACTION: Copying Text Sizing Image Files")
			set the textSizingImagePath to (my bundle()'s pathForResource_ofType_("makeTextSmaller", "png")) as string
			log ("AUTOMATOR ACTION textSizingImagePath: " & textSizingImagePath)
			-- copy the closebox image file to the target folder
			set targetFolderPath to POSIX path of target_folder_HFSpath
			set the commandString to ("cp -R" & space & (the quoted form of textSizingImagePath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			set the textSizingImagePath to (my bundle()'s pathForResource_ofType_("makeTextBigger", "png")) as string
			log ("AUTOMATOR ACTION textSizingImagePath: " & textSizingImagePath)
			-- copy the closebox image file to the target folder
			set the commandString to ("cp -R" & space & (the quoted form of textSizingImagePath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			
			-- WRITE THE MANIFEST FILE TO THE DESTINATION FOLDER
			log ("AUTOMATOR ACTION creating and writing manifest file to target folder")
			if my create_manifest(target_folder_HFSpath) is false then
				error (my NSLocalizedString("MANIFEST_WRITE_ERROR"))
			end if
			
			-- RENAME THE TEMP FOLDER TO THE INDICATED NAME
			log ("AUTOMATOR ACTION: Generating app name")
			if appName is "" then
				set the appName to (my NSLocalizedString("DEFAULT_APP_NAME"))
			end if
			tell application "Finder"
				set the parentDirectory to the container of folder target_folder_HFSpath
				set thisName to appName
				set the incrementValue to 1
				repeat
					if exists folder thisName of parentDirectory then
						set thisName to appName & "-" & (incrementValue as string)
						set incrementValue to incrementValue + 1
					else
						set the name of folder target_folder_HFSpath to thisName
						-- convert nested Finder reference to HFS path string
						set the target_folder_HFSpath to (folder thisName of parentDirectory) as string
						exit repeat
					end if
				end repeat
			end tell
			log ("AUTOMATOR ACTION: app name: " & thisName)
			
			-- return the path to the created folder
			set the resultingFolderCocoaPath to NSString's stringWithString_((POSIX path of target_folder_HFSpath))
			log ("AUTOMATOR ACTION result: " & resultingFolderCocoaPath)
			return resultingFolderCocoaPath
			
		on error errorMessage number errorNumber
			current application's NSBeep()
			set contents of errorRef to {NSAppleScriptErrorMessage:errorMessage, NSAppleScriptErrorNumber:-128}
			return missing value
		end try
		
	end runWithInput_fromAction_error_
	
	on write_to_file(this_data, target_file, append_data)
		tell application "System Events"
			try
				set the target_file to the target_file as string
				set the open_target_file to open for access file target_file with write permission
				if append_data is false then set eof of the open_target_file to 0
				write this_data to the open_target_file starting at eof as �class utf8�
				close access the open_target_file
				return true
			on error
				try
					close access file target_file
				end try
				return false
			end try
		end tell
	end write_to_file
	
	on extract_content_tree(this_path)
		set type_tree_info to do shell script ("mdls -name kMDItemContentTypeTree " & quoted form of this_path)
		set the types_list to paragraphs 2 thru -2 of type_tree_info
		
		repeat with i from 1 to count of types_list
			set this_item to item i of types_list
			set x to the offset of "\"" in this_item
			set this_item to text (x + 1) thru -1 of this_item
			set x to the offset of "\"" in this_item
			set this_item to text 1 thru (x - 1) of this_item
			set item i of the types_list to this_item
		end repeat
		
		return types_list
	end extract_content_tree
	
	on extract_caption(item_path)
		log ("AUTOMATOR ACTION: extract_caption(" & item_path & ")")
		try
			set the spotlight_result to do shell script "mdls -name kMDItemDescription " & quoted form of item_path
			if spotlight_result is "kMDItemDescription = (null)" then
				return false
			else
				return text ((length of "kMDItemDescription = ") + 2) thru -2 of spotlight_result
			end if
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			set captionReadError to (my NSLocalizedString("CAPTION_READ_ERROR"))
			return captionReadError
		end try
	end extract_caption
	
	on extract_dimensions(this_path)
		try
			log ("AUTOMATOR ACTION: extract_dimensions(" & this_path & ")")
			delay 0.5
			do shell script "mdimport " & quoted form of this_path
			delay 1
			do shell script "mdls -name kMDItemPixelHeight " & quoted form of this_path
			set the image_height to text from ((length of "kMDItemPixelHeight = ") + 1) to -1 of result
			do shell script "mdls -name kMDItemPixelWidth " & quoted form of this_path
			set the image_width to text from ((length of "kMDItemPixelWidth = ") + 1) to -1 of result
			return {image_width, image_height}
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end extract_dimensions
	
	on return_audioinfo(this_file)
		log ("AUTOMATOR ACTION: return_audioinfo()")
		set the item_path to the quoted form of this_file
		set the file_info to (do shell script "afinfo " & item_path)
		if (file_info is "") or ((file_info as string) contains "failed") then return false
		repeat with i from 1 to the count of paragraphs of the file_info
			set this_paragraph to paragraph i of the file_info
			if this_paragraph begins with "File type ID:" then
				set AppleScript's text item delimiters to space
				set the file_type to the last item of (every text item of this_paragraph)
				set AppleScript's text item delimiters to ""
			else if this_paragraph begins with "Data format:" then
				set AppleScript's text item delimiters to ", "
				set the sample_info to item 2 of (every text item of this_paragraph)
				set AppleScript's text item delimiters to space
				set the sample_rate to item -2 of (every text item of the sample_info)
				set AppleScript's text item delimiters to ""
			end if
		end repeat
		return {file_type, sample_rate} -- {"AIFF", "22050"}
	end return_audioinfo
	
	on replace_chars(this_text, search_string, replacement_string)
		set AppleScript's text item delimiters to the search_string
		set the item_list to every text item of this_text
		set AppleScript's text item delimiters to the replacement_string
		set this_text to the item_list as string
		set AppleScript's text item delimiters to ""
		return this_text
	end replace_chars
	
	on process_image(mediaPath, targetFolderHFSPath, defaultName)
		log ("AUTOMATOR ACTION: process_image(" & mediaPath & ", " & targetFolderHFSPath & ", " & defaultName & ")")
		set the maximum_width to 720
		try
			tell application "Image Events"
				-- start the Image Events application
				launch
				-- open the image file
				set this_image to open mediaPath
				-- check dimensions
				copy dimensions of this_image to {image_width, image_height}
				if image_width is greater than the maximum_width then
					-- perform action
					if image_width is less than image_height then
						set the scale_length to (image_height * target_length) / image_width
						set the scale_length to round scale_length rounding as taught in school
					else
						set the scale_length to the maximum_width
					end if
					scale this_image to size scale_length
				end if
				-- save the changes
				save this_image in file (targetFolderHFSPath & defaultName) as JPEG with icon
				-- purge the open image data
				close this_image
			end tell
			
			set the media_HTML to "<img src=\"" & defaultName & "\" style=\"max-width:100%;\" align=\"top\">"
			log ("AUTOMATOR ACTION: media_html: " & media_HTML)
			return media_HTML
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end process_image
	
	on create_manifest(source_folder)
		try
			log ("AUTOMATOR ACTION: create_manifest(" & source_folder & ")")
			set source_folder_HFS_path to source_folder as string
			set the source_folder_path to POSIX path of the source_folder_HFS_path
			set the base_path_length to the length of the source_folder_path
			
			tell application "Finder"
				set the manifest_items to (every document file of the entire contents of folder source_folder_HFS_path)
				repeat with i from 1 to count of manifest_items
					set item i of manifest_items to (item i of manifest_items) as string
				end repeat
			end tell
			
			set the manifest_text to "CACHE MANIFEST" & linefeed & "webapp.manifest"
			
			repeat with i from 1 to count of manifest_items
				set this_item to item i of manifest_items
				set this_path to POSIX path of this_item
				set the relative_path to text from (base_path_length + 1) to -1 of this_path
				set the manifest_text to manifest_text & return & the relative_path
			end repeat
			
			set the manifest_text to manifest_text & linefeed & linefeed & "NETWORK:" & linefeed & "http://www.apple.com/"
			
			set the target_file to (source_folder as string) & "webapp.manifest"
			return my write_to_file(manifest_text, target_file, false)
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end create_manifest
	
	-- LOCALIZATION ROUTINE
	on NSLocalizedString(key)
		return my bundle()'s localizedStringForKey_value_table_(key, missing value, missing value) as Unicode text
	end NSLocalizedString
	
end script
