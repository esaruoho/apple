--  Create_Multi_Column_Article_Web_App.applescript
--  Create Multi-Column Article Web App

--  Created by Sal Soghoian on 2/12/13.
--  Copyright (c) 2013 Sal Soghoian. All rights reserved.

## IMPORTANT: The file lightbox.js must be copied manually into the Resources folder of the built product bundle. Xcode does not tranfer the file automatically when the project target is built.

property HTML_code_indent : tab & tab & tab

script Create_Multi_Column_Article_Web_App
	property parent : class "AMBundleAction"
	
	on runWithInput_fromAction_error_(input, anAction, errorRef)
		try
			log ("AUTOMATOR ACTION: Create Multi-Column Article")
			-- GET PARAMETERS RECORD
			set parameters to my parameters()
			
			-- EXTRACT THE VARIOUS VALUES FOR THE INPUT PARAMETERS
			set appName to parameters's valueForKey_("appName") as string
			set ccLicenseIndicator to parameters's valueForKey_("CCLicenseIndicator") as integer
			set documentByline to parameters's valueForKey_("documentByline") as string
			set documentDescription to parameters's valueForKey_("documentDescription") as string
			set documentKeywords to parameters's valueForKey_("documentKeywords") as string
			set documentTitle to parameters's valueForKey_("documentTitle") as string
			set documentCopyright to parameters's valueForKey_("documenyCopyright") as string
			set mediaCaption to parameters's valueForKey_("mediaCaption") as string
			set mediaFilePath to parameters's valueForKey_("mediaFilePath") as string
			set mediaUseEmbeddedMetadataForCaption to parameters's valueForKey_("mediaUseEmbeddedMetadataForCaption") as boolean
			
			log ("AUTOMATOR ACTION: appName: " & appName)
			log ("AUTOMATOR ACTION: ccLicenseIndicator: " & ccLicenseIndicator)
			log ("AUTOMATOR ACTION: documentByline: " & documentByline)
			log ("AUTOMATOR ACTION: documentDescription: " & documentDescription)
			log ("AUTOMATOR ACTION: documentKeywords: " & documentKeywords)
			log ("AUTOMATOR ACTION: documentTitle: " & documentTitle)
			log ("AUTOMATOR ACTION: documentCopyright: " & documentCopyright)
			log ("AUTOMATOR ACTION: mediaCaption: " & mediaCaption)
			log ("AUTOMATOR ACTION: mediaFilePath: " & mediaFilePath)
			log ("AUTOMATOR ACTION: mediaUseEmbeddedMetadataForCaption: " & mediaUseEmbeddedMetadataForCaption)
			
			-- THE INPUT TEXT
			-- replace characters used in HTML with codes
			set thisText to my replace_chars((input as string), "&", "&amp;")
			set thisText to my replace_chars(thisText, "<", "&lt;")
			set thisText to my replace_chars(thisText, ">", "&gt;")
			-- divide the text into paragraphs
			set the sourceTextParagraphs to every paragraph of thisText
			-- get the first paragraph
			set the sourceTextFirstParagraph to the first item of sourceTextParagraphs
			set the sourceTextParagraphs to the rest of the the sourceTextParagraphs
			(*
		-- encase the remaining paragraphs in HTML tags
		set AppleScript's text item delimiters to ("</p>" & linefeed & tab & tab & tab & "<p>")
		set the HTMLBodyContent to sourceTextParagraphs as string
		set AppleScript's text item delimiters to ""
		set the HTMLBodyContent to tab & tab & tab & "<p>" & HTMLBodyContent & "</p>"
         *)
			repeat with i from 1 to the count of sourceTextParagraphs
				set thisParagraph to item i of the sourceTextParagraphs
				if i is 1 then
					if thisParagraph begins with "[SH]" then
						set thisParagraph to text 5 thru -1 of thisParagraph
						set the HTMLBodyContent to tab & tab & tab & "<p class=\"subhead\">" & thisParagraph & "</p>"
					else if thisParagraph begins with "[IT]" then
						set thisParagraph to text 5 thru -1 of thisParagraph
						set the HTMLBodyContent to tab & tab & tab & "<p class=\"italic\">" & thisParagraph & "</p>"
					else
						set the HTMLBodyContent to tab & tab & tab & "<p>" & thisParagraph & "</p>"
					end if
				else
					if thisParagraph begins with "[SH]" then
						set thisParagraph to text 5 thru -1 of thisParagraph
						set the HTMLBodyContent to HTMLBodyContent & linefeed & tab & tab & tab & "<p class=\"subhead\">" & thisParagraph & "</p>"
					else if thisParagraph begins with "[IT]" then
						set thisParagraph to text 5 thru -1 of thisParagraph
						set the HTMLBodyContent to HTMLBodyContent & linefeed & tab & tab & tab & "<p class=\"italic\">" & thisParagraph & "</p>"
					else
						set the HTMLBodyContent to HTMLBodyContent & linefeed & tab & tab & tab & "<p>" & thisParagraph & "</p>"
					end if
				end if
			end repeat
			
			log ("AUTOMATOR ACTION: Creating Folder")
			-- GENERATE A UUID (UNIQUE IDENTIFIER)
			set targetUUID to (do shell script "uuidgen")
			-- CREATE THE DESTINATION FOLDER
			set the desktopFolderCompletePath to (do shell script "echo ~/Desktop/")
			set the targetFolderPath to desktopFolderCompletePath & targetUUID
			do shell script ("mkdir -m u=rwx,go=rwx " & targetFolderPath)
			delay 1
			set the targetFolderHFSPath to targetFolderPath as POSIX file as string
			if targetFolderHFSPath does not end with ":" then set targetFolderHFSPath to targetFolderHFSPath & ":"
			
			-- LOCATE THE CSS AND HTML TEMPLATE FILES IN THIS ACTION'S RESOURCE FOLDER
			set the templateCSSPath to (my bundle()'s pathForResource_ofType_("main", "css")) as string
			set the templateIndexPath to (my bundle()'s pathForResource_ofType_("index", "html")) as string
			log ("AUTOMATOR ACTION: templateCSSPath: " & templateCSSPath)
			log ("AUTOMATOR ACTION: templateIndexPath: " & templateIndexPath)
			
			-- WRITE THE CSS FILE TO THE TARGET FOLDER
			log ("AUTOMATOR ACTION: Writing CSS")
			set the commandString to ("cp -R" & space & (the quoted form of templateCSSPath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			
			-- LOCATE THE LIGHTBOX FILES IN THIS ACTION'S RESOURCE FOLDER
			set the templateLightboxStylesheetPath to (my bundle()'s pathForResource_ofType_("lightbox", "css")) as string
			log ("AUTOMATOR ACTION: templateLightboxStylesheetPath: " & templateLightboxStylesheetPath)
			set the resourcesFolderPath to (do shell script "dirname " & (quoted form of templateLightboxStylesheetPath)) & "/"
			--set the templateLightboxJavaScriptPath to (my |bundle|()'s pathForResource_ofType_("lightbox", "js")) as string
			set the templateLightboxJavaScriptPath to resourcesFolderPath & "lightbox.js"
			log ("AUTOMATOR ACTION: templateLightboxJavaScriptPath: " & templateLightboxJavaScriptPath)
			
			-- WRITE THE LIGHTBOX FILES TO THE TARGET FOLDER
			log ("AUTOMATOR ACTION: Copying Lightbox Files")
			set the commandString to ("cp -R" & space & (the quoted form of templateLightboxStylesheetPath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			set the commandString to ("cp -R" & space & (the quoted form of templateLightboxJavaScriptPath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			
			-- COPY THE TEXT SIZING IMAGES TO THE TARGET FOLDER
			log ("AUTOMATOR ACTION: Copying Text Sizing Image Files")
			set the textSizingImagePath to (my bundle()'s pathForResource_ofType_("makeTextSmaller", "png")) as string
			-- copy the closebox image file to the target folder
			set the commandString to ("cp -R" & space & (the quoted form of textSizingImagePath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			
			set the textSizingImagePath to (my bundle()'s pathForResource_ofType_("makeTextBigger", "png")) as string
			-- copy the closebox image file to the target folder
			set the commandString to ("cp -R" & space & (the quoted form of textSizingImagePath) & space & (the quoted form of the targetFolderPath))
			do shell script commandString
			
			-- MEDIA HANDLERS
			if mediaFilePath is "" then
				log ("AUTOMATOR ACTION: No Media")
				set mediaSectionContent to "<!-- NO MEDIA CONTENT PROVIDED -->"
			else
				log ("AUTOMATOR ACTION: Processing Media")
				-- determine the type of media used: movie, audio, or image
				set mediaFilePath to do shell script "echo " & quoted form of mediaFilePath
				set the type_tree_list to my extract_content_tree(mediaFilePath)
				set the item_type to the first item of the type_tree_list
				
				if the type_tree_list contains "public.image" then
					log ("AUTOMATOR ACTION: Media is image")
					(* IMAGE *)
					set the closeboxImagePath to (my bundle()'s pathForResource_ofType_("closebox", "png")) as string
					-- copy the closebox image file to the target folder
					set the commandString to ("cp -R" & space & (the quoted form of closeboxImagePath) & space & (the quoted form of the targetFolderPath))
					do shell script commandString
					
					set the imageHTML to my process_image(mediaFilePath, targetFolderHFSPath, "image.jpg")
					
					log ("AUTOMATOR ACTION: Processing Caption")
					set the captionHTML to ""
					if mediaUseEmbeddedMetadataForCaption is true then
						set the imageCaption to my extract_caption(mediaFilePath)
						if the imageCaption is false or imageCaption is "" then
							set noCaptionError to (my NSLocalizedString("NO_CAPTION_ERROR"))
							set the captionHTML to ("<p class=\"caption\">" & noCaptionError & "</p>")
							set mediaCaption to noCaptionError
						else
							set the captionHTML to ("<p class=\"caption\">" & imageCaption & "</p>")
							set mediaCaption to (my replace_chars(imageCaption, "\"", "&quot;"))
						end if
					else if mediaCaption is not "" then
						set the captionHTML to ("<p class=\"caption\">" & mediaCaption & "</p>")
					end if
					
					-- make the image lightboxable
					log ("AUTOMATOR ACTION: Creating Lightbox Link")
					if the captionHTML is "" then
						set mediaSectionContent to "<a href=\"javascript:void(0);\"><img src=\"image.jpg\" align=\"top\" highResURL=\"image.jpg\" caption=\"" & (my replace_chars(mediaCaption, "\"", "&quot;")) & "\" onclick=\"void(0);lightboxThisImage(this);\"></a>"
					else
						set mediaSectionContent to "<a href=\"javascript:void(0);\"><img src=\"image.jpg\" align=\"top\" highResURL=\"image.jpg\" caption=\"" & (my replace_chars(mediaCaption, "\"", "&quot;")) & "\" onclick=\"void(0);lightboxThisImage(this);\"></a>" & captionHTML
					end if
					
					-- add the horizontal rule divider
					set mediaSectionContent to mediaSectionContent & linefeed & HTML_code_indent & "<hr>"
				else if the type_tree_list contains "public.movie" then
					log ("AUTOMATOR ACTION: Media is movie")
					(* MOVIE NOTE: movies are assumed to be pre-formatted for the iPad: h.264, etc. This action will not encode the movie. Use the Encode Media action for that task *)
					
					-- duplicate the movie to the target folder
					set the commandString to ("cp -R" & space & (the quoted form of mediaFilePath) & space & (the quoted form of the targetFolderPath))
					do shell script commandString
					
					-- create HTML
					set AppleScript's text item delimiters to "/"
					set the movieFileName to the last text item of the mediaFilePath
					set AppleScript's text item delimiters to ""
					set mediaSectionContent to "<video src=\"" & movieFileName & "\" controls=\"controls\" width=\"100%\"></video>"
					
					-- create caption HTML
					if the mediaCaption is "" then
						set the captionHTML to ""
					else
						set the captionHTML to ("<p class=\"caption\">" & mediaCaption & "</p>")
					end if
					
					set mediaSectionContent to mediaSectionContent & linefeed & HTML_code_indent & captionHTML
					set mediaSectionContent to mediaSectionContent & linefeed & HTML_code_indent & "<hr>"
					
				else if the type_tree_list contains "public.audio" then
					(* AUDIO FILE NOTE: audio in WAV, AIFF, or SDII will be encoded *)
					set the audio_data to my return_audioinfo(mediaFilePath)
					if audio_data is false then
						error (my NSLocalizedString("NOT_VALID_AUDIO_FILE_ERROR"))
					else
						copy audio_data to {audio_file_type, audiosample_rate}
					end if
					if audio_file_type is in {"AIFF", "Sd2f", "WAVE"} then
						set encode_audio_file to true
					else -- {"m4af"}
						set encode_audio_file to false
					end if
					
					-- PROCESS AUDIO FILE IF NEEDED
					if encode_audio_file is true then
						set the audioFilename to "audio.m4a"
						if targetFolderPath does not end with "/" then
							set targetAudioFile to targetFolderPath & "/" & audioFilename
						else
							set targetAudioFile to targetFolderPath & audioFilename
						end if
						set the command_string to "afconvert -f 'm4af' -d 'aac ' -s 1 " & (quoted form of the mediaFilePath) & space & (quoted form of the targetAudioFile)
						tell application "System Events"
							do shell script command_string
						end tell
					else
						set AppleScript's text item delimiters to "/"
						set the audioFilename to the last text item of the mediaFilePath
						set AppleScript's text item delimiters to ""
						
						set the commandString to ("cp -R" & space & (the quoted form of mediaFilePath) & space & (the quoted form of the targetFolderPath))
						do shell script commandString
					end if
					
					set mediaSectionContent to "<audio src=\"" & (my replace_chars(audioFilename, " ", "%20")) & "\" controls=\"controls\"></audio>"
					
					-- create caption HTML
					if the mediaCaption is not "" then
						set the captionHTML to ("<p class=\"caption\">" & mediaCaption & "</p>")
						set mediaSectionContent to mediaSectionContent & linefeed & HTML_code_indent & captionHTML
					end if
					set mediaSectionContent to mediaSectionContent & linefeed & HTML_code_indent & "<hr>"
				end if
			end if
			
			-- ADD ANY COPYRIGHT
			log ("AUTOMATOR ACTION: Procesing Copyright")
			if the documentCopyright is not "" then
				set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & "<hr>"
				set the copyrightHTML to ("<p class=\"copyright\">" & documentCopyright & "</p>")
				set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & copyrightHTML
			end if
			
			-- ADD CREATIVE COMMONS LICENSE
			log ("AUTOMATOR ACTION: Procesing License")
			if ccLicenseIndicator is not 0 then
				set the CCLinks to {"<a rel=\"license\" href=\"http://creativecommons.org/licenses/by/3.0/us/\">", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-sa/3.0/us/\">", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nd/3.0/us/\">", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc/3.0/us/\">", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/3.0/us/\">", "<a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-nd/3.0/us/\">"}
				set the CCDeclarations to {"This work is licensed under a Creative Commons Attribution 3.0 United States License", "This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License", "This work is licensed under a Creative Commons Attribution-No Derivative Works 3.0 United States License", "This work is licensed under a Creative Commons Attribution-Noncommercial 3.0 United States License", "This work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License", "This work is licensed under a Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 United States License"}
				set the CCImages to {"<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by/3.0/us/80x15.png\" align=\"top\">", "<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-sa/3.0/us/80x15.png\" align=\"top\">", "<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nd/3.0/us/80x15.png\" align=\"top\">", "<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc/3.0/us/80x15.png\" align=\"top\">", "<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc-sa/3.0/us/80x15.png\" align=\"top\">", "<img alt=\"Creative Commons License\" class=\"license\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc-nd/3.0/us/80x15.png\" align=\"top\">"}
				
				set the CCLink to item ccLicenseIndicator of the CCLinks
				set the CCDeclaration to item ccLicenseIndicator of the CCDeclarations
				set the CCImage to item ccLicenseIndicator of the CCImages
				
				set the CCImageLink to CCLink & CCImage & "</a>"
				set the CCDeclarationLink to "<p class=\"license\">" & CCLink & CCDeclaration & "</a>" & "</p>"
				
				set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & "<hr>"
				set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & CCImageLink
				set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & CCDeclarationLink
			end if
			
			-- ADD BLANK PARAGRAPH FOR THE END
			set HTMLBodyContent to HTMLBodyContent & linefeed & HTML_code_indent & "<div style=\"height:100%;\">&nbsp;</div>"
			
			-- READ THE HTML TEMPLATE INTO MEMORY
			log ("AUTOMATOR ACTION: Reading HTML Template")
			--set the templateHTMLData to read (templateIndexPath as POSIX file as alias) -- as �class utf8�
			set the templateHTMLData to read templateIndexPath -- as �class utf8�
			
			-- REPLACE PLACEHOLDERS IN THE TEMPLATE HTML (CURRENTLY IN MEMORY) WITH THE VALUES INPUT BY THE USER
			log ("AUTOMATOR ACTION: Replacing HTML Placeholders")
			set the templateHTMLData to (my replace_chars(templateHTMLData, "UUIDPLACEHOLDER", targetUUID))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "TITLEPLACEHOLDER", documentTitle))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "BYLINEPLACEHOLDER", documentByline))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "DESCRITPTIONPLACEHOLDER", documentDescription))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "KEYWORDSPLACEHOLDER", documentKeywords))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "MEDIASECTIONPLACEHOLDER", mediaSectionContent))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "FIRSTPARAGRAPHCONTENTPLACEHOLDER", sourceTextFirstParagraph))
			set the templateHTMLData to (my replace_chars(templateHTMLData, "CONTENTPLACEHOLDER", HTMLBodyContent))
			
			-- WRITE THE HTML DATA TO A FILE IN THE TARGET FOLDER
			log ("AUTOMATOR ACTION: Writing HTML file")
			set the targetHTMLHFSPath to targetFolderHFSPath & "index.html"
			if my write_to_file(templateHTMLData, targetHTMLHFSPath, false) is false then error (my NSLocalizedString("INDEX_WRITE_ERROR"))
			
			-- WRITE THE MANIFEST FILE TO THE DESTINATION FOLDER
			log ("AUTOMATOR ACTION: Writing manifest file")
			if my create_manifest(targetFolderHFSPath) is false then
				error (my NSLocalizedString("MANIFEST_WRITE_ERROR"))
			end if
			
			if appName is not "" then
				log ("AUTOMATOR ACTION: Generating app name")
				set the parentFolderPath to (do shell script "dirname " & (quoted form of targetFolderPath)) & "/"
				set targetItemPOSIXPath to parentFolderPath & appName
				set the folderExistenceStatus to (do shell script "[ -d " & (quoted form of targetItemPOSIXPath) & " ] && echo 'true' || echo 'false'") as boolean
				if folderExistenceStatus is true then
					set the nameIncrement to 1
					repeat
						-- create a new target path with the target item name incremented
						set targetItemPOSIXPath to parentFolderPath & appName & "-" & (nameIncrement as string)
						set the folderExistenceStatus to (do shell script "[ -d " & (quoted form of targetItemPOSIXPath) & " ] && echo 'true' || echo 'false'") as boolean
						if folderExistenceStatus is false then
							do shell script ("mv " & (quoted form of targetFolderPath) & space & (quoted form of targetItemPOSIXPath))
							set targetFolderPath to targetItemPOSIXPath
							exit repeat
						else
							set the nameIncrement to the nameIncrement + 1
						end if
					end repeat
				else
					do shell script ("mv " & (quoted form of targetFolderPath) & space & (quoted form of targetItemPOSIXPath))
					set targetFolderPath to targetItemPOSIXPath
				end if
			end if
			
			-- PASS THE POSIX PATH OF THE RESULTING FOLDER TO THE NEXT ACTION
			log ("AUTOMATOR ACTION: passing folder reference: " & targetFolderPath)
			return targetFolderPath
			
			return input
		on error errorMessage number errorNumber
			current application's NSBeep()
			set contents of errorRef to {NSAppleScriptErrorMessage:errorMessage, NSAppleScriptErrorNumber:-128}
			return missing value
		end try
	end runWithInput_fromAction_error_
	
	on write_to_file(this_data, target_file, append_data)
		tell application "System Events"
			try
				set the target_file to the target_file as string
				set the open_target_file to open for access file target_file with write permission
				if append_data is false then set eof of the open_target_file to 0
				write this_data to the open_target_file starting at eof as �class utf8�
				close access the open_target_file
				return true
			on error
				try
					close access file target_file
				end try
				return false
			end try
		end tell
	end write_to_file
	
	on replace_chars(this_text, search_string, replacement_string)
		set AppleScript's text item delimiters to the search_string
		set the item_list to every text item of this_text
		set AppleScript's text item delimiters to the replacement_string
		set this_text to the item_list as string
		set AppleScript's text item delimiters to ""
		return this_text
	end replace_chars
	
	on extract_content_tree(this_path)
		set type_tree_info to do shell script ("mdls -name kMDItemContentTypeTree " & quoted form of this_path)
		set the types_list to paragraphs 2 thru -2 of type_tree_info
		
		repeat with i from 1 to count of types_list
			set this_item to item i of types_list
			set x to the offset of "\"" in this_item
			set this_item to text (x + 1) thru -1 of this_item
			set x to the offset of "\"" in this_item
			set this_item to text 1 thru (x - 1) of this_item
			set item i of the types_list to this_item
		end repeat
		
		return types_list
	end extract_content_tree
	
	on extract_caption(item_path)
		log ("AUTOMATOR ACTION: extract_caption(" & item_path & ")")
		try
			set the spotlight_result to do shell script "mdls -name kMDItemDescription " & quoted form of item_path
			if spotlight_result is "kMDItemDescription = (null)" then
				return false
			else
				return text ((length of "kMDItemDescription = ") + 2) thru -2 of spotlight_result
			end if
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			set captionReadError to (my NSLocalizedString("CAPTION_READ_ERROR"))
			return captionReadError
		end try
	end extract_caption
	
	on extract_dimensions(this_path)
		try
			log ("AUTOMATOR ACTION: extract_dimensions(" & this_path & ")")
			delay 0.5
			do shell script "mdimport " & quoted form of this_path
			delay 1
			do shell script "mdls -name kMDItemPixelHeight " & quoted form of this_path
			set the image_height to text from ((length of "kMDItemPixelHeight = ") + 1) to -1 of result
			do shell script "mdls -name kMDItemPixelWidth " & quoted form of this_path
			set the image_width to text from ((length of "kMDItemPixelWidth = ") + 1) to -1 of result
			return {image_width, image_height}
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end extract_dimensions
	
	on return_audioinfo(this_file)
		log ("AUTOMATOR ACTION: return_audioinfo()")
		set the item_path to the quoted form of this_file
		set the file_info to (do shell script "afinfo " & item_path)
		if (file_info is "") or ((file_info as string) contains "failed") then return false
		repeat with i from 1 to the count of paragraphs of the file_info
			set this_paragraph to paragraph i of the file_info
			if this_paragraph begins with "File type ID:" then
				set AppleScript's text item delimiters to space
				set the file_type to the last item of (every text item of this_paragraph)
				set AppleScript's text item delimiters to ""
			else if this_paragraph begins with "Data format:" then
				set AppleScript's text item delimiters to ", "
				set the sample_info to item 2 of (every text item of this_paragraph)
				set AppleScript's text item delimiters to space
				set the sample_rate to item -2 of (every text item of the sample_info)
				set AppleScript's text item delimiters to ""
			end if
		end repeat
		return {file_type, sample_rate} -- {"AIFF", "22050"}
	end return_audioinfo
	
	on process_image(mediaPath, targetFolderHFSPath, defaultName)
		log ("AUTOMATOR ACTION: process_image(" & mediaPath & ", " & targetFolderHFSPath & ", " & defaultName & ")")
		set the maximum_width to 1024
		try
			tell application "Image Events"
				-- start the Image Events application
				launch
				-- open the image file
				set this_image to open mediaPath
				-- check dimensions
				copy dimensions of this_image to {image_width, image_height}
				if image_width is greater than the maximum_width then
					-- perform action
					if image_width is less than image_height then
						set the scale_length to (image_height * target_length) / image_width
						set the scale_length to round scale_length rounding as taught in school
					else
						set the scale_length to the maximum_width
					end if
					scale this_image to size scale_length
				end if
				-- save the changes
				save this_image in file (targetFolderHFSPath & defaultName) as JPEG with icon
				-- purge the open image data
				close this_image
			end tell
			
			set the media_HTML to "<img src=\"" & defaultName & "\" align=\"top\">"
			return media_HTML
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end process_image
	
	on create_manifest(source_folder)
		try
			log ("AUTOMATOR ACTION: create_manifest(" & source_folder & ")")
			set source_folder_HFS_path to source_folder as string
			set the source_folder_path to POSIX path of the source_folder_HFS_path
			set the base_path_length to the length of the source_folder_path
			
			tell application "Finder"
				set the manifest_items to (every document file of the entire contents of folder source_folder_HFS_path)
				repeat with i from 1 to count of manifest_items
					set item i of manifest_items to (item i of manifest_items) as string
				end repeat
			end tell
			
			set the manifest_text to "CACHE MANIFEST" & linefeed & "webapp.manifest"
			
			repeat with i from 1 to count of manifest_items
				set this_item to item i of manifest_items
				set this_path to POSIX path of this_item
				set the relative_path to text from (base_path_length + 1) to -1 of this_path
				set the manifest_text to manifest_text & return & the relative_path
			end repeat
			
			set the manifest_text to manifest_text & linefeed & linefeed & "NETWORK:" & linefeed & "http://www.apple.com/"
			
			set the target_file to (source_folder as string) & "webapp.manifest"
			return my write_to_file(manifest_text, target_file, false)
		on error error_message
			log ("AUTOMATOR ACTION: ERROR: " & error_message)
			return error_message
		end try
	end create_manifest
	
	-- LOCALIZATION ROUTINE
	on NSLocalizedString(key)
		return my bundle()'s localizedStringForKey_value_table_(key, missing value, missing value) as Unicode text
	end NSLocalizedString
	
end script
