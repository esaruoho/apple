(* 
AN EXAMPLE OF USING DEFAULTS INSTEAD OF PROPERTIES. THIS APPLET WILL DISPLAY AND STORE THE COUNT OF TIMES IT HAS BEEN RUN.

DOCUMENTATION FOR THE DEFAULTS COMMAND-LINE UTILITY:
<https://developer.apple.com/library/mac/documentation/Darwin/Reference/ManPages/man1/defaults.1.html>
*)


-- USE GLOBAL VARIABLES INSTEAD OF PROPERTIES. BE SURE TO INCLUDE THE VARIABLE REPRESENTING THIS APPLET�S BUNDLE IDENTIFIER, WHICH CAN BE SET IN THE BUNDLE DRAWER OF THIS APPLET.
global thisAppletID, dialogCount

on run
	-- GET THE ID OF THIS APPLET. 
	-- NOTE: IF YOU ARE RUNNING THIS APPLET IN THE APPLESCRIPT EDITOR, CHOOSE �Run Application� FROM THE �Script� MENU, INSTEAD OF CLICKING THE �Run� BUTTON.
	set thisAppletID to the id of me
	
	-- CREATE A TRY BLOCK FOR EACH PROPERTY
	try
		-- ATTEMPT TO READ THE STORED SETTING
		set dialogCount to (do shell script "defaults read " & thisAppletID & space & "dialogCount") as integer
	on error
		-- ERROR PROBABLY MEANS THERE IS NO PREFERENCES FILE OR MATCHING PROPERTY, SO CREATE ONE BY STORING THE PROPERTY AND ITS DEFAULT VALUE:
		do shell script "defaults write " & thisAppletID & space & "dialogCount" & space & "-int" & space & "0"
		set dialogCount to 0
	end try
	
	-- ALERT THE USER TO THE CURRENT VALUE OF THE PROPERTY
	if dialogCount is 0 then
		set dialogMessage to "This is the first time this applet has been run!"
	else if dialogCount is 1 then
		set dialogMessage to ("This applet has been run " & dialogCount & " time before.") as string
	else
		set dialogMessage to ("This applet has been run " & dialogCount & " times before.") as string
	end if
	display dialog dialogMessage buttons {"Show Prefs File", "Reset", "Continue"} default button 3
	
	-- DETERMINE ACTION BASED ON USER RESPONSE TO THE DIALOG
	set the userAction to button returned of the result
	if userAction is "Reset" then
		set dialogCount to 0
	else if userAction is "Continue" then
		set dialogCount to dialogCount + 1
	else
		set the preferencesFolderPath to (path to preferences folder from user domain)
		set the prefsFilePath to (preferencesFolderPath as string) & thisAppletID & ".plist"
		tell application "Finder" to reveal document file the prefsFilePath
	end if
end run

on quit
	-- BEFORE QUITTING THE APPLET, STORE THE EXISTING VALUE OF THE PROPERTY VARIABLE
	try
		set the commandString to thisAppletID & space & "dialogCount" & space & "-int" & space & (dialogCount as string)
		do shell script "defaults write" & space & commandString
		-- CONTINUE THE QUIT PROCESS
		continue quit
	on error errorMessage
		display alert "DEFAULTS ERROR" message errorMessage
	end try
end quit