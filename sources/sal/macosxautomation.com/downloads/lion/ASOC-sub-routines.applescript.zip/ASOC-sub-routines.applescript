-- NUMBERS

on convertNumberToDecimalValue(thisNumber, maxDecimalPlaces)
	--> returns comma delimited, rounded, localized decimal value, e.g.: (3.64525432506E+5/0 places = 364525) (0.2375/2 places = 24)
	-- DOCUMENTATION: http://developer.apple.com/library/ios/documentation/Cocoa/Reference/Foundation/Classes/NSNumberFormatter_Class/Reference/Reference.html
	if maxDecimalPlaces is greater than 0 then
		set decimalIndicators to "."
		repeat maxDecimalPlaces times
			set decimalIndicators to decimalIndicators & "#"
		end repeat
	else
		set decimalIndicators to ""
	end if
	set thisFormatter to current application's NSNumberFormatter's alloc()'s init()
	tell thisFormatter to setFormat_("0" & decimalIndicators)
	set resultingText to thisFormatter's stringFromNumber_(thisNumber)
	return (resultingText as string)
end convertNumberToDecimalValue

on convertNumberToPercentValue(thisNumber)
	--> returns comma delimited, rounded, localized percentage value, e.g.: (0.2345 = 23%) (0.2375 = 24%)
	-- DOCUMENTATION: http://developer.apple.com/library/ios/documentation/Cocoa/Reference/Foundation/Classes/NSNumberFormatter_Class/Reference/Reference.html
	tell current application's NSNumberFormatter to set resultingText to localizedStringFromNumber_numberStyle_(thisNumber, current application's NSNumberFormatterPercentStyle)
	return (resultingText as string)
end convertNumberToPercentValue

on convertNumberToCurrencyValue(thisNumber)
	--> returns comma delimited, rounded, localized currency value, e.g.: (9128 = $9,128.00) (9978.2485 = $9,128.25)
	-- DOCUMENTATION: http://developer.apple.com/library/ios/documentation/Cocoa/Reference/Foundation/Classes/NSNumberFormatter_Class/Reference/Reference.html
	tell current application's NSNumberFormatter to set resultingText to localizedStringFromNumber_numberStyle_(thisNumber, current application's NSNumberFormatterCurrencyStyle)
	return (resultingText as string)
end convertNumberToCurrencyValue

on convertNumberToWords(thisNumber)
	--> returns a numeric value in words, e.g: (23 = �twenty-three�) (23.75 = �twenty-three point seven five�)
	-- DOCUMENTATION: http://developer.apple.com/library/ios/documentation/Cocoa/Reference/Foundation/Classes/NSNumberFormatter_Class/Reference/Reference.html
	tell current application's NSNumberFormatter to set resultingText to localizedStringFromNumber_numberStyle_(thisNumber, current application's NSNumberFormatterSpellOutStyle)
	return (resultingText as string)
end convertNumberToWords

-- PERCENT ENCODING

on decodePercentEncoding(sourceText)
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-BCIECHFE
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-SW59
	
	-- Create an instance of NSString from the passed text, by calling the NSString class method stringWithString:
	set the sourceString to current application's NSString's stringWithString_(sourceText)
	-- apply the indicated transformation
	set the adjustedString to the sourceString's stringByReplacingPercentEscapesUsingEncoding_(current application's NSUTF8StringEncoding)
	-- convert from NSString to AppleScript string
	return (adjustedString as string)
end decodePercentEncoding

on encodeUsingPercentEncoding(sourceText)
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-BCIBFDCB
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-SW59
	
	-- Create an instance of NSString from the passed text, by calling the NSString class method stringWithString:
	set the sourceString to current application's NSString's stringWithString_(sourceText)
	-- apply the indicated transformation
	set the adjustedString to the sourceString's stringByAddingPercentEscapesUsingEncoding_(current application's NSUTF8StringEncoding)
	-- convert from NSString to AppleScript string
	return (adjustedString as string)
end encodeUsingPercentEncoding

-- STRINGS

on sortListStrings(sourceList)
	-- sorts a passed AppleScript list of strings
	-- DOCUMENTATION: https://developer.apple.com/library/mac/#documentation/Cocoa/Reference/Foundation/Classes/NSArray_Class/NSArray.html#//apple_ref/doc/uid/TP40003620
	
	-- convert AppleScript list to Cocoa array
	set the CocoaArray to current application's NSArray's arrayWithArray_(sourceList)
	-- sort the Cocoa array
	set the sortedItems to CocoaArray's sortedArrayUsingSelector_("localizedStandardCompare:")
	-- return the Cocoa array coerced to an AppleScript list
	return (sortedItems as list)
end sortListStrings

on concatenateListWithSeparatorString(sourceList, separatorString)
	-- concatenates a passed AppleScript list of strings using a passed separator string
	-- DOCUMENTATION: https://developer.apple.com/library/mac/#documentation/Cocoa/Reference/Foundation/Classes/NSArray_Class/NSArray.html#//apple_ref/doc/uid/TP40003620
	
	-- convert AppleScript list to Cocoa array
	set the CocoaArray to current application's NSArray's arrayWithArray_(sourceList)
	-- concatenate the Cooca array using the passed separator string
	set the concatenatedCocoaString to CocoaArray's componentsJoinedByString_(separatorString)
	-- return the Cocoa string coerced to an AppleScript string
	return (concatenatedCocoaString as string)
end concatenateListWithSeparatorString

on findAndReplaceStringInText(sourceText, searchString, replacementString)
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-SW6
	
	-- Create an instance of NSString from the passed text, by calling the NSString class method stringWithString:
	set the sourceString to current application's NSString's stringWithString_(sourceText)
	-- Replace the search string with the replacement string, by calling a method on the newly created instance
	set the adjustedString to the sourceString's stringByReplacingOccurrencesOfString_withString_(searchString, replacementString)
	-- convert from NSString to AppleScript string
	return (adjustedString as string)
end findAndReplaceStringInText

on changeCaseOfText(sourceText, caseIndicator)
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-uppercaseString
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-lowercaseString
	-- DOCUMENTATION: http://developer.apple.com/library/mac/documentation/Cocoa/Reference/Foundation/Classes/NSString_Class/Reference/NSString.html#//apple_ref/doc/uid/20000154-capitalizedString
	
	-- Create an instance of NSString from the passed text, by calling the NSString class method stringWithString:
	set the sourceString to current application's NSString's stringWithString_(sourceText)
	-- apply the indicated transformation
	if the caseIndicator is 0 then
		set the adjustedString to sourceString's uppercaseString()
	else if the caseIndicator is 1 then
		set the adjustedString to sourceString's lowercaseString()
	else
		set the adjustedString to sourceString's capitalizedString()
	end if
	-- convert from NSString to AppleScript string
	return (adjustedString as string)
end changeCaseOfText